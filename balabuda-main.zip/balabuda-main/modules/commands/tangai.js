module.exports.config = {
	name: "tangai",
	version: "1.0.0",
	hasPermssion: 0,
	credits: "Syn(dkh)",
	description: "Tán gái vip pro",
	commandCategory: "game",
	cooldowns: 0
};

module.exports.run = ({ event, api }) => api.sendMessage(`Em đẹp lắm \nAnh đã muốn pen houses trên đà lạt với em , yêu ngay cái nhìn đầu tiên, sự ngây thơ, hồn nhiên với trái tim ấm nồng của em đã chinh phục anh. \nCảm ơn cha mẹ đã sinh anh ra ở kiếp này để được gặp và yêu em như hôm nay. \nTình yêu anh dành cho em ngày càng nhiều hơn. \nLúc này đây anh mới cảm nhận rõ về tình yêu ấy. \nEm biết không? EM chính là nàng thơ tuyệt đẹp của trần thế này với vẻ đẹp lung linh nghiêng nước nghiêng thành khiến bao người phải chìm đắm trong sắc đẹp của em. \nEm như là một bông hoa đẹp nhất trong cả vườn hoa vậy, Em chính là một hình mẫu lí tưởng của sắc đẹp. \nAnh rất là may mắn khi có thể chiêm ngưỡng được vẻ đẹp như thế. Giống như là một phước lành mà Chúa đã trao tặng cho em vậy. \nÔi em thật là đẹp quá, cảm vào giây phút này để anh được ngắm em nhiều \nCó lẽ suốt đời này anh chẳng thể nào quên được em ôi bông hoa chẳng thuộc về anhh❤`, event.threadID, event.messageID);