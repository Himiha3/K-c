module.exports.config = {
  name: "nthinh",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "DongDev",
  description: "",
  commandCategory: "Tìm kiếm",
  usages: "[]",
  cooldowns: 0,
  usePrefix: false,
};
module.exports.run = async function ({ api:p, event:e }) {
 p.sendMessage(`Nờ thịnh nờ thịnh nờ thinhhhh 👉👈\nFrom: Công Thịnh đz`, e.threadID);
  }