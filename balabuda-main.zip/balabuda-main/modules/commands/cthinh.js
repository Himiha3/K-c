module.exports.config = {
  name: "cthinh",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "DongDev",
  description: "",
  commandCategory: "Tìm kiếm",
  usages: "[]",
  cooldowns: 0,
  usePrefix: false,
};
module.exports.run = async function ({ api:p, event:e }) {
 p.sendMessage(`Nờ Thịnh là 1 người nổi tiếng về đạo lý ôg ta rất đz nhưng ôg ta quyết định sẽ từ bỏ đạo lí và tiến đến đỉnh cao của 1 người viết văn tán gái9x:)\nFrom: Nờ thịnh nờ thịnh nờ thinhhhh 👉👈`, e.threadID);
  }